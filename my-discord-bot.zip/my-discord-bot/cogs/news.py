import discord
from discord.ext import commands
import aiohttp
import os

class News(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.api_key = os.getenv("NEWS_API_KEY")

    @commands.command()
    async def news(self, ctx, topic: str = "technology"):
        """Latest news fetch karo"""
        url = "https://gnews.io/api/v4/search"
        
        async with aiohttp.ClientSession() as session:
            params = {
                "q": topic,
                "token": self.api_key,
                "lang": "en",
                "max": 5
            }
            async with session.get(url, params=params) as resp:
                data = await resp.json()

        articles = data.get("articles", [])
        if not articles:
            await ctx.send("❌ Koi news nahi mili!")
            return

        embed = discord.Embed(
            title=f"📰 Top 5 News — {topic.title()}",
            color=discord.Color.red()
        )
        
        for i, article in enumerate(articles[:5], 1):
            embed.add_field(
                name=f"{i}. {article['title'][:60]}...",
                value=f"[Read More]({article['url']})",
                inline=False
            )
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(News(bot))
    