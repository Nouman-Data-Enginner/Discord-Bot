import discord
from discord.ext import commands
import aiohttp

class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def joke(self, ctx):
        """Random joke sunao"""
        async with aiohttp.ClientSession() as session:
            async with session.get("https://v2.jokeapi.dev/joke/Any?safe-mode") as resp:
                data = await resp.json()

        if data["type"] == "single":
            await ctx.send(f"😂 {data['joke']}")
        else:
            await ctx.send(f"😂 {data['setup']}\n\n||{data['delivery']}||")

    @commands.command()
    async def quote(self, ctx):
        """Motivational quote do"""
        async with aiohttp.ClientSession() as session:
            async with session.get("https://zenquotes.io/api/random") as resp:
                data = await resp.json()

        embed = discord.Embed(
            description=f'💭 *"{data[0]["q"]}"*',
            color=discord.Color.green()
        )
        embed.set_footer(text=f"— {data[0]['a']}")
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Fun(bot))