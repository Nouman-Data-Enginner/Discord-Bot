import discord
from discord.ext import commands
import aiohttp

class Crypto(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def crypto(self, ctx, coin: str = "bitcoin"):
        """Crypto price check karo"""
        url = "https://api.coingecko.com/api/v3/simple/price"
        
        async with aiohttp.ClientSession() as session:
            params = {
                "ids": coin.lower(),
                "vs_currencies": "usd",
                "include_24hr_change": "true"
            }
            async with session.get(url, params=params) as resp:
                data = await resp.json()

        if coin.lower() not in data:
            await ctx.send("❌ Coin nahi mila! (e.g. bitcoin, ethereum, solana)")
            return

        coin_data = data[coin.lower()]
        price = coin_data["usd"]
        change = coin_data["usd_24h_change"]
        
        color = discord.Color.green() if change > 0 else discord.Color.red()
        arrow = "📈" if change > 0 else "📉"
        
        embed = discord.Embed(
            title=f"💰 {coin.title()} Price",
            color=color
        )
        embed.add_field(name="💵 Price (USD)", value=f"${price:,.2f}")
        embed.add_field(name=f"{arrow} 24h Change", value=f"{change:.2f}%")
        embed.set_footer(text="Powered by CoinGecko")
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Crypto(bot))